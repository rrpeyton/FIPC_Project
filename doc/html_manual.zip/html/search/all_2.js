var searchData=
[
  ['comandos_20de_20api_53',['Comandos de API',['../group___a_p_i___commands.html',1,'']]],
  ['canmoveabsolute_54',['canMoveAbsolute',['../class_f_i_p_c___axis.html#ae06288417c4d0ae1e2bccda34059f2e1',1,'FIPC_Axis']]],
  ['canmoverelative_55',['canMoveRelative',['../class_f_i_p_c___axis.html#a50642205eaa14cfa5b6a01336cbb88cd',1,'FIPC_Axis']]],
  ['configmoveabsolute_56',['configMoveAbsolute',['../class_f_i_p_c___axis.html#acb58e1cc83d714458d6730dcbca06da1',1,'FIPC_Axis']]],
  ['configmoverelative_57',['configMoveRelative',['../class_f_i_p_c___axis.html#a79d37141a196906068316ed96feb5805',1,'FIPC_Axis']]]
];
