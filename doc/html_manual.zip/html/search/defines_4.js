var searchData=
[
  ['init_5faccel_5ftime_277',['INIT_ACCEL_TIME',['../_f_i_p_c___axis_8cpp.html#afce258fd37824bb074dc50b029d9faed',1,'FIPC_Axis.cpp']]],
  ['init_5ffactor_5fspeed_278',['INIT_FACTOR_SPEED',['../_f_i_p_c___axis_8cpp.html#ab70ada18acabca21acf67441d5c75e90',1,'FIPC_Axis.cpp']]]
];
