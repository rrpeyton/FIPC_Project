var searchData=
[
  ['getaccelerationtime_90',['getAccelerationTime',['../class_f_i_p_c___a_p_i.html#a13a4421d5e7c1a13bf81f21e56ffe48f',1,'FIPC_API::getAccelerationTime()'],['../class_f_i_p_c___axis.html#a829d578b233ce7e47740e0cc07978a7f',1,'FIPC_Axis::getAccelerationTime()']]],
  ['getallreport_91',['getAllReport',['../class_f_i_p_c___a_p_i.html#aa59961420a6e50e8c2b07e9a07a780c3',1,'FIPC_API']]],
  ['getcommands_92',['getCommands',['../class_f_i_p_c___a_p_i.html#ad9698e15cf5ffb649895ead47d73e1ad',1,'FIPC_API']]],
  ['getcurrentposition_93',['getCurrentPosition',['../class_f_i_p_c___a_p_i.html#afa6a44280222ed05a9ebfdae6b704957',1,'FIPC_API::getCurrentPosition()'],['../class_f_i_p_c___axis.html#acab279b17a163e50384db0bcca1dd246',1,'FIPC_Axis::getCurrentPosition()']]],
  ['getreport_94',['getReport',['../class_f_i_p_c___a_p_i.html#a52f546672a8f09763187db825db84935',1,'FIPC_API::getReport()'],['../class_f_i_p_c___axis.html#a75fe2b13107553d823e009f8065ba369',1,'FIPC_Axis::getReport()']]],
  ['getspeed_95',['getSpeed',['../class_f_i_p_c___a_p_i.html#abd80f6c1f37b9760689555b562f1d153',1,'FIPC_API::getSpeed()'],['../class_f_i_p_c___axis.html#af21ab0e939dbfcba7b2064d7f8b7be90',1,'FIPC_Axis::getSpeed()']]],
  ['getstatus_96',['getStatus',['../class_f_i_p_c___a_p_i.html#affe290dc60096aa7fa05406597808ce5',1,'FIPC_API::getStatus()'],['../class_f_i_p_c___axis.html#a6a10465595f6e3bbf5ca61eea1f50986',1,'FIPC_Axis::getStatus()'],['../class_f_i_p_c___homing.html#aad83289c341952779e22ee0cd564d615',1,'FIPC_Homing::getStatus()']]],
  ['getswitch_97',['getSwitch',['../class_f_i_p_c___homing.html#af4e6c666a47c47edbc79aa720d95d623',1,'FIPC_Homing']]]
];
