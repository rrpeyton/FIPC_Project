var indexSectionsWithContent =
{
  0: "_acdefghilmnrstx",
  1: "f",
  2: "f",
  3: "cefgilrst",
  4: "_adftx",
  5: "aehm",
  6: "aehms",
  7: "adehins",
  8: "c",
  9: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Enumeraciones",
  6: "Valores de enumeraciones",
  7: "defines",
  8: "Grupos",
  9: "Páginas"
};

