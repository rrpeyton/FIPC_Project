var searchData=
[
  ['taskexec_201',['TaskExec',['../_f_i_p_c___project_8ino.html#abc515553136175e9e33de6b36e7307d0',1,'FIPC_Project.ino']]],
  ['taskreadaction_202',['TaskReadAction',['../_f_i_p_c___project_8ino.html#a4355dca545d0d82e0ad693872bdacb03',1,'FIPC_Project.ino']]],
  ['taskreportstatus_203',['TaskReportStatus',['../_f_i_p_c___project_8ino.html#ad5ae78c64f0586b9b8d42005b84b2fb5',1,'FIPC_Project.ino']]]
];
