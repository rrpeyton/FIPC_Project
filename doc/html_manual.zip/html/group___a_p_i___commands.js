var group___a_p_i___commands =
[
    [ "API_ABSOLUTE", "group___a_p_i___commands.html#ga3ff77b145f254e49ddacfbf3b6d52899", null ],
    [ "API_ACCEL", "group___a_p_i___commands.html#ga7844bd40ff4962105338748fef5b24d6", null ],
    [ "API_DISABLE", "group___a_p_i___commands.html#ga937672e8594d6cca6be9b3402c160ab3", null ],
    [ "API_ENABLE", "group___a_p_i___commands.html#gaece4f9e8695445e3e61f3c4564d86251", null ],
    [ "API_HOME", "group___a_p_i___commands.html#ga248bfc11ade4a4b10268f60c90d9af6b", null ],
    [ "API_HOME_ALL", "group___a_p_i___commands.html#ga87faa6b991a8a04fde68ac6a43b18cde", null ],
    [ "API_Q_ACCEL", "group___a_p_i___commands.html#gaf8674bf4a61130b16c02c1adc745c1f8", null ],
    [ "API_Q_ISMOV", "group___a_p_i___commands.html#ga2a783798fc93cb9677df9dcdd8fde89f", null ],
    [ "API_Q_POS", "group___a_p_i___commands.html#ga51e3f0c3a135f3c56d75c1bc251821e3", null ],
    [ "API_Q_REPO", "group___a_p_i___commands.html#ga78ea8e8afdf2e51468173ab5c832c3b1", null ],
    [ "API_Q_REPO_ALL", "group___a_p_i___commands.html#ga79afea780f8b4033674f5c3f1cd9de6f", null ],
    [ "API_Q_STAT", "group___a_p_i___commands.html#ga4bb7ca4a35dd3411fe25ba36c042190d", null ],
    [ "API_Q_VELO", "group___a_p_i___commands.html#gab5d1aa5af0631c133f5970e232c6f244", null ],
    [ "API_RELATIVE", "group___a_p_i___commands.html#ga71122a9f239ca4b4dba4b97a61070192", null ],
    [ "API_STOP", "group___a_p_i___commands.html#ga3edc652e692386d75560aa6bae7c22df", null ],
    [ "API_STOP_ALL", "group___a_p_i___commands.html#gabf0697c5a0f28caec71f3712d67b2708", null ],
    [ "API_SYNC_ABS", "group___a_p_i___commands.html#gaf85bbaa23879a95b1d473b803ea09340", null ],
    [ "API_SYNC_REL", "group___a_p_i___commands.html#ga84151d07118df9f3c73efe4588c58086", null ],
    [ "API_VELO", "group___a_p_i___commands.html#ga72cfc2b8a7a5fa616b9818cfac5d276b", null ]
];