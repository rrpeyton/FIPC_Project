var class_f_i_p_c___a_p_i =
[
    [ "FIPC_API", "class_f_i_p_c___a_p_i.html#a33479ba713cc701dcb924c6053e03e0a", null ],
    [ "exec", "class_f_i_p_c___a_p_i.html#adbe5d9e4114b3df092e354d4e140beed", null ],
    [ "getAccelerationTime", "class_f_i_p_c___a_p_i.html#a13a4421d5e7c1a13bf81f21e56ffe48f", null ],
    [ "getAllReport", "class_f_i_p_c___a_p_i.html#aa59961420a6e50e8c2b07e9a07a780c3", null ],
    [ "getCommands", "class_f_i_p_c___a_p_i.html#ad9698e15cf5ffb649895ead47d73e1ad", null ],
    [ "getCurrentPosition", "class_f_i_p_c___a_p_i.html#afa6a44280222ed05a9ebfdae6b704957", null ],
    [ "getReport", "class_f_i_p_c___a_p_i.html#a52f546672a8f09763187db825db84935", null ],
    [ "getSpeed", "class_f_i_p_c___a_p_i.html#abd80f6c1f37b9760689555b562f1d153", null ],
    [ "getStatus", "class_f_i_p_c___a_p_i.html#affe290dc60096aa7fa05406597808ce5", null ],
    [ "isRunning", "class_f_i_p_c___a_p_i.html#ac0b41fac459f669a405ca62c3e2adb8e", null ],
    [ "request", "class_f_i_p_c___a_p_i.html#a1fec2c7dcd1b7ee4a9bba4e9e4540af2", null ],
    [ "requestAction", "class_f_i_p_c___a_p_i.html#aede3ad21d0e8e3812b9bd9e4a597f248", null ],
    [ "setAccelerationTime", "class_f_i_p_c___a_p_i.html#aecbf0c96f6e97b2a44e4c4d1e084a64f", null ],
    [ "setSpeed", "class_f_i_p_c___a_p_i.html#a567bf360bc3ed3a719fbfdc458a1a5eb", null ],
    [ "syncMotionAbs", "class_f_i_p_c___a_p_i.html#a4815226494488ede31d8548df54dc787", null ],
    [ "syncMotionRel", "class_f_i_p_c___a_p_i.html#adff7c55def64df26fd77edfe5af0af94", null ],
    [ "_axis", "class_f_i_p_c___a_p_i.html#a86295cbd0191ac084c6645483f103584", null ]
];